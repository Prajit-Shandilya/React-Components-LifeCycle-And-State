import React, { Component } from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';

export default class App extends Component {
  constructor() {
    super();
    this.state = {
      counter: 0,
      btnColor:"blue"
    };
  }

  componentDidMount() {
    setInterval(this.incrementCounter,100)
  }

  changeBtnClr=()=>{
    var hexacodes='0123456789ABCDEF'
    var colorcode="#"
    for(var i=0;i<6;i++){
      colorcode+=hexacodes[Math.floor(Math.random()*16)]


    }
    this.setState({btnColor:colorcode});
  }
  incrementCounter = () => {
    this.setState({ counter: this.state.counter + 1 });
  };

  render() {
    return (
      <View style={{ flex: 1 }}>
        <Text style={{ marginTop: 50, marginLeft: 170 }}>
          {this.state.counter}
        </Text>
          <Button title="Click Me" color={this.state.btnColor} onPress={this.changeBtnClr}/>
      </View>
    );
  }
  }
